enum GameState {
    case intro, cave, cave_2, egypt, phoenicia
}
